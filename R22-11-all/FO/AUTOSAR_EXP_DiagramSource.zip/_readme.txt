Document Title:                 Explanation of Diagram Source
Document Owner:                 AUTOSAR
Document Responsibility:        AUTOSAR
Document Identification Number: 877
Document Status:                published
Part of AUTOSAR Standard:       Foundation
Part of Standard Release:       R22-11
Date:                           2022-11-24
