Document Title:                 Collection of blueprints for AUTOSAR M1 models
Document Owner:                 AUTOSAR
Document Responsibility:        AUTOSAR
Document Identification Number: 621
Document Status:                published
Part of AUTOSAR Standard:       Foundation
Part of Standard Release:       R22-11
Date:                           2022-11-24

The AUTOSAR specification contains several AUTOSAR models, such as the BSW UML 
model, and other information, such as traceability, in the AUTOSAR arxml 
format. In order to support the users of AUTOSAR and to get a closer 
understanding of the expected model content for an AUTOSAR system these AUTOSAR 
models are delivered as blueprints within this archive.

This ZIP-archive contains a set of arxml files with following content. All this
information is collected from some other AUTOSAR specification document. This 
ZIP archive does not introduce any new content.
* Meta Data of the deliverable (disclaimer, version, readme)
* KeywordSet for Predefined Names
* PortInterfaces and types for standardized service interfaces
* SwAddrMethods for SWS Memory Mapping

All contents are provided as Blueprints. They are not supposed to be used 
directly for a productive system, but the descriptions of a productive system 
can be derived from these blueprints.

Please note, that the KeywordSet for Predefined Names belongs to the contents 
of deliverable TR_PredefinedNames (UID 600) and therefore shows the UID and 
Version of this deliverable although it is part of the General Blueprints.


xml.xsd
    This is the schema for the xml namespace as provided by W3C.
    For xml.xsd the W3C license applies, which can be found on
    https://www.w3.org/Consortium/Legal/2015/copyright-software-and-document:

        License

        By obtaining and/or copying this work, you (the licensee) agree that you have read, understood, and will comply with the following terms and conditions.

        Permission to copy, modify, and distribute this work, with or without modification, for any purpose and without fee or royalty is hereby granted, provided that you include the following on ALL copies of the work or portions thereof, including modifications:

            The full text of this NOTICE in a location viewable to users of the redistributed or derivative work.
            Any pre-existing intellectual property disclaimers, notices, or terms and conditions. If none exist, the W3C Software and Document Short Notice should be included.
            Notice of any changes or modifications, through a copyright statement on the new code or document such as "This software or document includes material copied from or derived from [title and URI of the W3C document]. Copyright © [YEAR] W3C® (MIT, ERCIM, Keio, Beihang)." 

        Disclaimers

        THIS WORK IS PROVIDED "AS IS," AND COPYRIGHT HOLDERS MAKE NO REPRESENTATIONS OR WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO, WARRANTIES OF MERCHANTABILITY OR FITNESS FOR ANY PARTICULAR PURPOSE OR THAT THE USE OF THE SOFTWARE OR DOCUMENT WILL NOT INFRINGE ANY THIRD PARTY PATENTS, COPYRIGHTS, TRADEMARKS OR OTHER RIGHTS.

        COPYRIGHT HOLDERS WILL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF ANY USE OF THE SOFTWARE OR DOCUMENT.

        The name and trademarks of copyright holders may NOT be used in advertising or publicity pertaining to the work without specific, written prior permission. Title to copyright in this work will at all times remain with copyright holders.
